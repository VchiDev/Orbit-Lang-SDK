# Flux Engine 1.3.1

Flux Engine is Orbit's practical indie-game engine. The primary gameplay API is a real-time, windowed 2D loop rendered through Orbit's RGBA software renderer. Scenes support ambient illumination and soft radial point lights. A separate deterministic software renderer remains available for offline screenshots and asset generation.

## A playable game

```orbit
lux.loadLib(orbit.fluxengine.lux)
var game = flux.scene("Crystal Hunt", "#17243b")
flux.entity(game, "Meadow", 0, 280, 640, 80, "#355b43", "rect")
var player = flux.entity(game, "Player", 60, 160, 34, 48, "#ffcc66", "rect")
flux.control(game, player, 220, "arrows_wasd")
flux.collectible(game, "Gem A", 220, 120, 22, "#65e8ff")
flux.collectible(game, "Gem B", 480, 220, 22, "#c4b5fd")
flux.goal(game, 2, "All gems collected!")
flux.ambient(game, "#ffffff", 0.35)
flux.light(game, 240, 130, 210, "#ffdf9e", 1.2)
flux.light(game, 500, 260, 150, "#78bfff", 0.8)
flux.run(game, 640, 360, "Crystal Hunt", 60)
```

Run the source with `orbit run src/main.orb` or package it with `orbitpkg build .` and run the result with `orbitpkg run .\MyGame.orbit`. `flux.run` opens a native game window and starts the frame loop. Arrow keys and WASD move a controlled entity; diagonal movement is normalized; collectibles increment the score; a goal message appears when the target count is reached. Escape or the window close button exits.

## Scene API

- `flux.scene(name, background)` — create a scene record.
- `flux.entity(scene, name, x, y, width, height, color, shape)` — add a visible rectangle, circle, line or text entity.
- `flux.velocity(entity, vx, vy)` — set continuous velocity.
- `flux.control(scene, player, speed, scheme)` — enable arrow-key/WASD movement (`arrows`, `wasd`, `arrows_wasd`).
- `flux.collectible(scene, name, x, y, size, color)` — create a collectable circle.
- `flux.goal(scene, count, message)` — set the required collection count and win message.
- `flux.ambient(scene, color, intensity)` — set global ambient color and brightness (0–1).
- `flux.light(scene, x, y, radius, color, intensity)` — add a soft radial point light; the returned light record can be edited or removed.
- `flux.remove_light(scene, light)` — remove a point light.
- `flux.label(scene, text, x, y, color, size)` — add a HUD label.
- `flux.set_bounds(scene, enabled)` — keep the controlled player inside the game window.
- `flux.update(scene, dt, gravity)` — advance the scene manually; delta time is clamped to 0.25 seconds.
- `flux.render(scene, canvas)` — render one frame to a `graphics` canvas.
- `flux.find`, `flux.remove`, `flux.collide` — entity lookup, removal and AABB collision test.
- `flux.run(scene, width, height, title, fps)` — interactive display and loop; default 60 FPS, supported range 15–144.

## Real game window versus PNG rendering

`flux.run(...)` is the play mode: it creates a native window, continuously updates the world, polls keyboard and pointer state, handles movement and collectible collisions, and renders every frame. `flux.render(scene, canvas)` is different: it draws exactly one off-screen frame into a software canvas, including the scene lighting. Use `graphics.save_png` after `flux.render` for screenshots, automated asset generation, thumbnails or headless CI. A script that only calls `flux.scene`, `flux.render` and `graphics.save_png` does not launch a playable game because it did not call `flux.run`.

## Display requirements

Interactive play requires Python's Tkinter module and a graphical desktop session. On Linux, Tkinter may need to be installed as the OS package `python3-tk`; on Windows, use a Python distribution that includes Tcl/Tk. Headless servers can still use the PNG renderer. Flux does not silently substitute a PNG when a window cannot be opened; it returns an actionable runtime error.

Flux 1.3.1 is a practical 2D indie-game engine. It includes the playable desktop loop and basic scene/entity systems, but does not yet include a visual editor, sprite-atlas importer, full animation state machine, built-in real-time audio mixer, multiplayer stack or integrated rigid-body physics solver. The `graphics3d` library offers CPU mesh and triangle rendering for simple 3D scenes, but it is not yet integrated into the Flux 2D scene loop.

## Scene lighting

```orbit
lux.loadLib(orbit.fluxengine.lux)
var game = flux.scene("Lantern Meadow", "#101827")
flux.entity(game, "Ground", 0, 270, 640, 90, "#355b43", "rect")
var player = flux.entity(game, "Player", 100, 170, 36, 54, "#ffcc66", "rect")
flux.control(game, player, 220, "arrows_wasd")
flux.ambient(game, "#ffffff", 0.28)
var lantern = flux.light(game, 170, 180, 190, "#ffcc80", 1.35)
flux.light(game, 480, 220, 150, "#70bfff", 0.9)
flux.run(game, 640, 360, "Lantern Meadow", 60)
```

Ambient light sets the minimum scene illumination. Point lights use a smooth quadratic falloff from their center to their radius and support colored light. Multiple lights combine. Light coordinates are in scene pixels. This release provides 2D illumination and shading, but not cast shadows or a deferred/GPU lighting pipeline.

## Live software graphics windows (2D and 3D)

The graphics library can now present canvases in a live desktop window. Use the same canvas repeatedly inside a `while` loop; `graphics.present` displays the current frame at the requested window frame rate and `graphics.is_open` processes window events. This is not a screenshot export.

```orbit
lux.loadLib(orbit.graphics.lux)
var display = graphics.open_window(640, 360, "Live 2D", 60, "#101827")
var frame = graphics.canvas(640, 360, "#101827")
var x = 20
while graphics.is_open(display) {
    graphics.clear(frame, "#101827")
    graphics.circle(frame, x, 160, 24, "#72d7ff")
    graphics.present(display, frame)
    x += 2
    if x > 620 { x = 20 }
}
```

The same display API works with `graphics3d.render_solid` and `graphics3d.render_wireframe`. See `examples/graphics2d-live/main.orb`, `examples/graphics3d-live/main.orb`, and `examples/flux-lighting/main.orb`. The 3D renderer now uses ambient plus directional Lambert diffuse shading; the `ambient` argument on `render_solid` controls the base illumination. It remains a lightweight CPU renderer for low-poly scenes, not a GPU pipeline.
