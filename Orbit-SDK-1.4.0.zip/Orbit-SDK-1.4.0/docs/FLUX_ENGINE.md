# Flux Engine 1.4.0

Flux Engine is Orbit's practical indie-game engine with **integrated 2D and 3D scene modes**. Both modes use the same native window, frame loop, input bridge, and RGBA software renderer. It is a CPU renderer intended for small and medium indie projects, not a GPU/AAA engine.

## 2D scene quick start

```orbit
lux.loadLib(orbit.fluxengine.lux)
var game = flux.scene("Crystal Hunt", "#17243b")
var player = flux.entity(game, "Player", 60, 160, 34, 48, "#ffcc66", "rect")
flux.control(game, player, 220, "arrows_wasd")
flux.collectible(game, "Gem A", 220, 120, 22, "#65e8ff")
flux.goal(game, 1, "Crystal collected!")
flux.run(game, 640, 360, "Crystal Hunt", 60)
```

## 3D scene quick start

```orbit
lux.loadLib(orbit.fluxengine.lux)
lux.loadLib(orbit.graphics3d.lux)
var game = flux.scene3d("Crystal Garden", "#101827")
var crystalMesh = graphics3d.sphere(1.0, 10, 18)
var crystal = flux.model(game, "Crystal", crystalMesh, "#65dfff", [0, 0, 0], [0, 0, 0], 1.4)
flux.camera(game, [0, 1.2, -8], [0, 0, 0], [0, 1, 0], 62)
flux.light3d(game, [-0.4, 0.7, -1.0], 0.28)
flux.spin(crystal, 0.2, 0.7, 0.1)
flux.run(game, 800, 600, "Crystal Garden", 60)
```

Run `orbit run examples/flux-3d/main.orb` from the SDK root to launch the included sample. Interactive windows require Python Tkinter and a graphical desktop session.

## Scene and 2D API

- `flux.scene(name, background)` — create a 2D scene.
- `flux.entity(scene, name, x, y, width, height, color, shape)` — add a rectangle, circle, or text entity.
- `flux.velocity(entity, vx, vy)` — set 2D velocity.
- `flux.control(scene, player, speed, scheme)` — arrow-key/WASD movement.
- `flux.collectible(scene, name, x, y, size, color)` and `flux.goal(scene, count, message)` — collection goals.
- `flux.ambient(scene, color, intensity)` and `flux.light(scene, x, y, radius, color, intensity)` — 2D lighting.
- `flux.update(scene, dt, gravity)`, `flux.render(scene, canvas)`, `flux.collide(a,b)`, `flux.find`, `flux.remove` — manual simulation and rendering helpers.

## 3D scene and model API

- `flux.scene3d(name, background)` — create a 3D scene.
- `graphics3d.cube(size)` and `graphics3d.sphere(radius, rings, segments)` — create built-in meshes. Sphere detail is clamped to 3–64 rings and 6–128 segments.
- `graphics3d.mesh(vertices, edges, faces)` — create a custom mesh. Vertices are `[x,y,z]`; faces contain vertex indices.
- `flux.model(scene, name, mesh, color, position, rotation, scale)` — add a mesh instance to the scene. Rotations are in radians.
- `flux.camera(scene, position, target, up, fov, near)` — configure the perspective camera. Field of view is in degrees.
- `flux.spin(model, x, y, z)` — set angular velocity in radians per second.
- `flux.model_velocity(model, x, y, z)` — set world-space movement speed.
- `flux.control3d(scene, model, speed)` — attach basic keyboard movement: WASD/arrows move on the ground plane; Space and Shift move vertically.
- `flux.light3d(scene, direction, ambient)` — set one directional light and ambient level for the 3D scene.
- `flux.render3d(scene, canvas)` — render one 3D frame without opening a window.

`flux.run` chooses the renderer from the scene type. It keeps the existing 2D loop for `flux.scene(...)` and uses the 3D camera/model renderer for `flux.scene3d(...)`. The same `flux.update` and `flux.render` functions work for either mode.

## Detail versus performance

The 3D renderer is CPU-based. More faces produce more geometric detail and more finely varying flat-shaded surfaces, but also increase transform, lighting, sorting, and rasterization work. Start with a sphere around 8–12 rings and 12–20 segments; increase detail only when the silhouette needs it. Keep static mesh data reusable and animate model transforms rather than rebuilding vertices in Orbit code every frame. The canvas polygon rasterizer uses clipped row spans, and live frame presentation uses PNG encoding with fast compression.

## Current boundaries

Flux 3D currently provides mesh instances, Euler transforms, a perspective camera, directional Lambert lighting, painter-order triangle rendering, basic model movement, and a single directional light. It does not yet provide GPU acceleration, texture mapping, skeletal animation, shadows, physically based materials, mesh importers, 3D rigid-body collision/physics, a visual editor, or multiplayer. The existing 2D entity, lighting, and collectible APIs remain available and unchanged.
