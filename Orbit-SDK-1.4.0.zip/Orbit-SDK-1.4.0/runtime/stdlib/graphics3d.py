"""Small deterministic CPU 3D renderer with wireframe and flat-shaded triangles."""
import math
from . import graphics

def mesh(vertices, edges=None, faces=None):
    verts = [tuple(float(n) for n in p[:3]) for p in vertices]
    edge_list = [tuple(map(int, e)) for e in (edges or [])]
    face_list = [tuple(map(int, f)) for f in (faces or [])]
    for group, label in ((edge_list, "edge"), (face_list, "face")):
        for item in group:
            if len(item) < (2 if label == "edge" else 3) or any(i < 0 or i >= len(verts) for i in item):
                raise ValueError(f"Invalid mesh {label}: {item}")
    return {"vertices": verts, "edges": edge_list, "faces": face_list}

def cube(size=1.0):
    s=float(size)/2
    v=[(-s,-s,-s),(s,-s,-s),(s,s,-s),(-s,s,-s),(-s,-s,s),(s,-s,s),(s,s,s),(-s,s,s)]
    e=[(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7)]
    f=[(3,2,1,0),(5,6,7,4),(1,5,4,0),(2,6,5,1),(3,7,6,2),(7,3,0,4)]
    return {"vertices":v,"edges":e,"faces":f}

def sphere(radius=1.0, rings=8, segments=12):
    """Create a UV sphere. Increase rings/segments for more detailed low-poly shading."""
    radius=float(radius); rings=max(3,min(64,int(rings))); segments=max(6,min(128,int(segments)))
    vertices=[(0.0,radius,0.0)]
    for r in range(1,rings):
        phi=math.pi*r/rings; y=radius*math.cos(phi); ring=radius*math.sin(phi)
        for j in range(segments):
            theta=2.0*math.pi*j/segments
            vertices.append((ring*math.cos(theta),y,ring*math.sin(theta)))
    bottom=len(vertices); vertices.append((0.0,-radius,0.0))
    faces=[]; edges=set()
    def edge(a,b): edges.add((min(a,b),max(a,b)))
    for j in range(segments):
        nxt=(j+1)%segments; faces.append((0,1+nxt,1+j)); edge(0,1+j); edge(1+j,1+nxt)
    for r in range(rings-2):
        start=1+r*segments; nxt=start+segments
        for j in range(segments):
            k=(j+1)%segments
            faces.append((start+j,start+k,nxt+k,nxt+j))
            edge(start+j,nxt+j); edge(start+j,start+k)
    last=1+(rings-2)*segments
    for j in range(segments):
        nxt=(j+1)%segments; faces.append((last+j,last+nxt,bottom)); edge(last+j,bottom); edge(last+j,last+nxt)
    return {"vertices":vertices,"edges":sorted(edges),"faces":faces}

def transform(model, rotation=None, position=None, scale=None):
    rx,ry,rz=map(float,rotation or [0,0,0]); px,py,pz=map(float,position or [0,0,0])
    if scale is None: sx=sy=sz=1.0
    elif isinstance(scale,(int,float)): sx=sy=sz=float(scale)
    else: sx,sy,sz=map(float,scale)
    out=[]
    for x,y,z in model["vertices"]:
        x,y,z=x*sx,y*sy,z*sz
        y,z=y*math.cos(rx)-z*math.sin(rx),y*math.sin(rx)+z*math.cos(rx)
        x,z=x*math.cos(ry)+z*math.sin(ry),-x*math.sin(ry)+z*math.cos(ry)
        x,y=x*math.cos(rz)-y*math.sin(rz),x*math.sin(rz)+y*math.cos(rz)
        out.append((x+px,y+py,z+pz))
    return {"vertices":out,"edges":list(model.get("edges",[])),"faces":list(model.get("faces",[]))}

def project_point(point,width,height,camera_z=5.0,scale=80.0,near=0.1):
    x,y,z=point; d=float(camera_z)-float(z)
    if d <= float(near): return None
    factor=float(scale)/d
    return [float(width)/2+x*factor,float(height)/2-y*factor]

def _shade(color, intensity):
    base=graphics._color(color)
    k=max(0.18,min(1.0,float(intensity)))
    return tuple(int(base[i]*k) for i in range(3))+(base[3],)

def render_solid(canvas, model, color="#78bfff", camera_z=5.0, scale=100.0, light_dir=(-0.4,0.6,-1.0), ambient=0.22, backface_culling=False, near=0.1):
    """Painter-sorted flat-shaded CPU polygons. Best for small/medium low-poly meshes."""
    vertices=model["vertices"]; faces=model.get("faces",[])
    lx,ly,lz=map(float,light_dir); lm=math.sqrt(lx*lx+ly*ly+lz*lz) or 1.0
    light=(lx/lm,ly/lm,lz/lm); ambient=max(0.0,min(1.0,float(ambient)))
    base=graphics._color(color); rendered=[]
    for face in faces:
        if len(face)<3: continue
        points=[vertices[i] for i in face]
        if any(float(camera_z)-p[2] <= float(near) for p in points): continue
        a,b,c=points[0],points[1],points[2]
        ux,uy,uz=b[0]-a[0],b[1]-a[1],b[2]-a[2]
        vx,vy,vz=c[0]-a[0],c[1]-a[1],c[2]-a[2]
        nx,ny,nz=uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx
        nm=math.sqrt(nx*nx+ny*ny+nz*nz) or 1.0
        if backface_culling and (nx*a[0]+ny*a[1]+nz*(a[2]-camera_z)) >= 0: continue
        ndotl=max(0.0,(nx*light[0]+ny*light[1]+nz*light[2])/nm)
        intensity=ambient+(1.0-ambient)*ndotl
        k=max(0.18,min(1.0,intensity)); shade=tuple(int(base[i]*k) for i in range(3))+(base[3],)
        projected=[project_point(p,canvas["width"],canvas["height"],camera_z,scale,near) for p in points]
        depth=sum(p[2] for p in points)/len(points)
        # Triangulate n-gons as a fan for the software rasterizer.
        for i in range(1,len(projected)-1):
            rendered.append((depth,[projected[0],projected[i],projected[i+1]],shade))
    for _,points,shade in sorted(rendered,key=lambda item:item[0]):
        graphics.polygon(canvas,points,shade,True)
    return canvas

def render_wireframe(canvas,model,color="#ffffff",camera_z=5.0,scale=80.0,near=0.1):
    projected=[project_point(p,canvas["width"],canvas["height"],camera_z,scale,near) for p in model["vertices"]]
    for a,b in model.get("edges",[]):
        if projected[a] is not None and projected[b] is not None:
            graphics.line(canvas,*projected[a],*projected[b],color)
    return canvas
