"""Small deterministic CPU 3D renderer with wireframe and flat-shaded triangles."""
import math
from . import graphics

def mesh(vertices, edges=None, faces=None):
    verts = [tuple(float(n) for n in p[:3]) for p in vertices]
    edge_list = [tuple(map(int, e)) for e in (edges or [])]
    face_list = [tuple(map(int, f)) for f in (faces or [])]
    for group, label in ((edge_list, "edge"), (face_list, "face")):
        for item in group:
            if len(item) < (2 if label == "edge" else 3) or any(i < 0 or i >= len(verts) for i in item):
                raise ValueError(f"Invalid mesh {label}: {item}")
    return {"vertices": verts, "edges": edge_list, "faces": face_list}

def cube(size=1.0):
    s=float(size)/2
    v=[(-s,-s,-s),(s,-s,-s),(s,s,-s),(-s,s,-s),(-s,-s,s),(s,-s,s),(s,s,s),(-s,s,s)]
    e=[(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7)]
    f=[(3,2,1,0),(5,6,7,4),(1,5,4,0),(2,6,5,1),(3,7,6,2),(7,3,0,4)]
    return {"vertices":v,"edges":e,"faces":f}

def sphere(radius=1.0, rings=8, segments=12):
    """Create a UV sphere. Increase rings/segments for more detailed low-poly shading."""
    radius=float(radius); rings=max(3,min(64,int(rings))); segments=max(6,min(128,int(segments)))
    vertices=[(0.0,radius,0.0)]
    for r in range(1,rings):
        phi=math.pi*r/rings; y=radius*math.cos(phi); ring=radius*math.sin(phi)
        for j in range(segments):
            theta=2.0*math.pi*j/segments
            vertices.append((ring*math.cos(theta),y,ring*math.sin(theta)))
    bottom=len(vertices); vertices.append((0.0,-radius,0.0))
    faces=[]; edges=set()
    def edge(a,b): edges.add((min(a,b),max(a,b)))
    for j in range(segments):
        nxt=(j+1)%segments; faces.append((0,1+nxt,1+j)); edge(0,1+j); edge(1+j,1+nxt)
    for r in range(rings-2):
        start=1+r*segments; nxt=start+segments
        for j in range(segments):
            k=(j+1)%segments
            faces.append((start+j,start+k,nxt+k,nxt+j))
            edge(start+j,nxt+j); edge(start+j,start+k)
    last=1+(rings-2)*segments
    for j in range(segments):
        nxt=(j+1)%segments; faces.append((last+j,last+nxt,bottom)); edge(last+j,bottom); edge(last+j,last+nxt)
    return {"vertices":vertices,"edges":sorted(edges),"faces":faces}

def icosphere(radius=1.0, subdivisions=3):
    """Create an evenly tessellated icosphere (20 * 4**subdivisions triangles).

    Subdivision levels 3 and 4 produce 1,280 and 5,120 triangles,
    respectively, making this a useful default family for detailed models.
    """
    radius=float(radius); subdivisions=max(0,min(5,int(subdivisions)))
    t=(1.0+math.sqrt(5.0))/2.0
    raw=[(-1,t,0),(1,t,0),(-1,-t,0),(1,-t,0),
         (0,-1,t),(0,1,t),(0,-1,-t),(0,1,-t),
         (t,0,-1),(t,0,1),(-t,0,-1),(-t,0,1)]
    vertices=[]
    for x,y,z in raw:
        length=math.sqrt(x*x+y*y+z*z)
        vertices.append((radius*x/length,radius*y/length,radius*z/length))
    faces=[(0,11,5),(0,5,1),(0,1,7),(0,7,10),(0,10,11),
           (1,5,9),(5,11,4),(11,10,2),(10,7,6),(7,1,8),
           (3,9,4),(3,4,2),(3,2,6),(3,6,8),(3,8,9),
           (4,9,5),(2,4,11),(6,2,10),(8,6,7),(9,8,1)]
    for _ in range(subdivisions):
        midpoint_cache={}
        def midpoint(a,b):
            key=(min(a,b),max(a,b))
            found=midpoint_cache.get(key)
            if found is not None: return found
            va,vb=vertices[a],vertices[b]
            x=(va[0]+vb[0])*0.5; y=(va[1]+vb[1])*0.5; z=(va[2]+vb[2])*0.5
            length=math.sqrt(x*x+y*y+z*z) or 1.0
            index=len(vertices); vertices.append((radius*x/length,radius*y/length,radius*z/length))
            midpoint_cache[key]=index
            return index
        refined=[]
        for a,b,c in faces:
            ab=midpoint(a,b); bc=midpoint(b,c); ca=midpoint(c,a)
            refined.extend(((a,ab,ca),(b,bc,ab),(c,ca,bc),(ab,bc,ca)))
        faces=refined
    # Ensure consistent outward winding for lighting and backface culling.
    oriented=[]
    for a,b,c in faces:
        va,vb,vc=vertices[a],vertices[b],vertices[c]
        ux,uy,uz=vb[0]-va[0],vb[1]-va[1],vb[2]-va[2]
        vx,vy,vz=vc[0]-va[0],vc[1]-va[1],vc[2]-va[2]
        nx,ny,nz=uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx
        center=(va[0]+vb[0]+vc[0],va[1]+vb[1]+vc[1],va[2]+vb[2]+vc[2])
        oriented.append((a,c,b) if nx*center[0]+ny*center[1]+nz*center[2] < 0 else (a,b,c))
    edge_set=set()
    for a,b,c in oriented:
        edge_set.add((min(a,b),max(a,b)))
        edge_set.add((min(b,c),max(b,c)))
        edge_set.add((min(c,a),max(c,a)))
    return {"vertices":vertices,"edges":sorted(edge_set),"faces":oriented}


def triangle_count(model):
    """Return the number of triangles after fan-triangulating mesh faces."""
    return sum(max(0,len(face)-2) for face in model.get("faces",[]))


def transform(model, rotation=None, position=None, scale=None):
    rx,ry,rz=map(float,rotation or [0,0,0]); px,py,pz=map(float,position or [0,0,0])
    if scale is None: sx=sy=sz=1.0
    elif isinstance(scale,(int,float)): sx=sy=sz=float(scale)
    else: sx,sy,sz=map(float,scale)
    out=[]
    for x,y,z in model["vertices"]:
        x,y,z=x*sx,y*sy,z*sz
        y,z=y*math.cos(rx)-z*math.sin(rx),y*math.sin(rx)+z*math.cos(rx)
        x,z=x*math.cos(ry)+z*math.sin(ry),-x*math.sin(ry)+z*math.cos(ry)
        x,y=x*math.cos(rz)-y*math.sin(rz),x*math.sin(rz)+y*math.cos(rz)
        out.append((x+px,y+py,z+pz))
    return {"vertices":out,"edges":list(model.get("edges",[])),"faces":list(model.get("faces",[]))}

def project_point(point,width,height,camera_z=5.0,scale=80.0,near=0.1):
    x,y,z=point; d=float(camera_z)-float(z)
    if d <= float(near): return None
    factor=float(scale)/d
    return [float(width)/2+x*factor,float(height)/2-y*factor]

def _shade(color, intensity):
    base=graphics._color(color)
    k=max(0.18,min(1.0,float(intensity)))
    return tuple(int(base[i]*k) for i in range(3))+(base[3],)

def render_solid(canvas, model, color="#78bfff", camera_z=5.0, scale=100.0, light_dir=(-0.4,0.6,-1.0), ambient=0.22, backface_culling=False, near=0.1):
    """Render flat-shaded CPU triangles with shared-vertex projection caching.

    Mesh vertices are projected once per draw instead of once per face. This
    reduces repeated math substantially on dense meshes (1k-10k triangles).
    """
    vertices=model["vertices"]; faces=model.get("faces",[])
    width,height=canvas["width"],canvas["height"]
    camera_z=float(camera_z); near=float(near); scale=float(scale)
    lx,ly,lz=map(float,light_dir); lm=math.sqrt(lx*lx+ly*ly+lz*lz) or 1.0
    light=(lx/lm,ly/lm,lz/lm); ambient=max(0.0,min(1.0,float(ambient)))
    base=graphics._color(color)
    camera_depth=[camera_z-float(p[2]) for p in vertices]
    projected=[None]*len(vertices)
    for index,p in enumerate(vertices):
        d=camera_depth[index]
        if d>near:
            factor=scale/d
            projected[index]=(width*0.5+float(p[0])*factor,height*0.5-float(p[1])*factor)
    rendered=[]
    append=rendered.append
    for face in faces:
        if len(face)<3: continue
        a=vertices[face[0]]; b=vertices[face[1]]; c=vertices[face[2]]
        ux,uy,uz=b[0]-a[0],b[1]-a[1],b[2]-a[2]
        vx,vy,vz=c[0]-a[0],c[1]-a[1],c[2]-a[2]
        nx,ny,nz=uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx
        nm=math.sqrt(nx*nx+ny*ny+nz*nz)
        if nm<=1e-12: continue
        if backface_culling and (nx*a[0]+ny*a[1]+nz*(a[2]-camera_z)) >= 0: continue
        ndotl=max(0.0,(nx*light[0]+ny*light[1]+nz*light[2])/nm)
        intensity=ambient+(1.0-ambient)*ndotl
        k=max(0.18,min(1.0,intensity))
        shade=(int(base[0]*k),int(base[1]*k),int(base[2]*k),base[3])
        p0=projected[face[0]]
        if p0 is None: continue
        depth_sum=camera_depth[face[0]]
        for i in range(1,len(face)-1):
            i1,i2=face[i],face[i+1]
            p1,p2=projected[i1],projected[i2]
            if p1 is None or p2 is None: continue
            depth=(depth_sum+camera_depth[i1]+camera_depth[i2])/3.0
            append((depth,(p0,p1,p2),shade))
    rendered.sort(key=lambda item:item[0],reverse=True)
    for _,points,shade in rendered:
        graphics.polygon(canvas,points,shade,True)
    return canvas

def render_wireframe(canvas,model,color="#ffffff",camera_z=5.0,scale=80.0,near=0.1):
    projected=[project_point(p,canvas["width"],canvas["height"],camera_z,scale,near) for p in model["vertices"]]
    for a,b in model.get("edges",[]):
        if projected[a] is not None and projected[b] is not None:
            graphics.line(canvas,*projected[a],*projected[b],color)
    return canvas
