"""Flux Engine 2D scene model, simulation helpers, and interactive game entry point."""
from runtime.stdlib import graphics
from runtime.stdlib import graphics3d
import math


def scene(name="Scene", background="#202633"):
    return {
        "name": str(name), "background": background, "entities": [], "labels": [],
        "time": 0.0, "score": 0, "goal": 0, "message": "", "controllers": [],
        "width": 640, "height": 360, "gravity": 0.0,
        "ambient_color": "#ffffff", "ambient_intensity": 0.72, "lights": [],
        "dimension": 2, "models": [], "controllers3d": [], "camera": {"position": [0.0, 0.0, -6.0],
        "target": [0.0, 0.0, 0.0], "up": [0.0, 1.0, 0.0], "fov": 60.0,
        "near": 0.1}, "light3d": {"direction": [-0.4, 0.6, -1.0], "ambient": 0.24},
    }


def entity(scene, name="Entity", x=0, y=0, width=32, height=32, color="#ffffff", shape="rect"):
    e = {
        "name": str(name), "x": float(x), "y": float(y), "width": float(width),
        "height": float(height), "color": color, "shape": str(shape), "vx": 0.0,
        "vy": 0.0, "visible": True, "rotation": 0.0, "kind": "entity",
    }
    scene["entities"].append(e)
    return e


def scene3d(name="3D Scene", background="#101827"):
    """Create a Flux scene that renders 3D mesh models instead of 2D entities."""
    result=scene(name,background); result["dimension"]=3
    return result


def camera(scene, position=None, target=None, up=None, fov=60.0, near=0.1):
    cam=scene.setdefault("camera", {})
    if position is not None: cam["position"]=[float(v) for v in position]
    if target is not None: cam["target"]=[float(v) for v in target]
    if up is not None: cam["up"]=[float(v) for v in up]
    cam["fov"]=max(20.0,min(120.0,float(fov))); cam["near"]=max(0.05,float(near))
    return cam


def model(scene, name, mesh, color="#78bfff", position=None, rotation=None, scale=1.0):
    if not isinstance(mesh,dict) or "vertices" not in mesh or "faces" not in mesh:
        raise ValueError("flux.model expects a graphics3d mesh")
    item={"name":str(name),"mesh":mesh,"color":color,
          "position":list(map(float,position or [0,0,0])),
          "rotation":list(map(float,rotation or [0,0,0])),"scale":scale,
          "velocity":[0.0,0.0,0.0],"angular_velocity":[0.0,0.0,0.0],"visible":True}
    scene.setdefault("models",[]).append(item); scene["dimension"]=3
    return item


def control3d(scene, item, speed=3.0):
    if item not in scene.get("models",[]): raise ValueError("Controlled 3D model must belong to this scene")
    scene.setdefault("controllers3d",[]).append({"model":item,"speed":max(0.1,float(speed))})
    return item


def model_velocity(item, x=0.0, y=0.0, z=0.0):
    item["velocity"]=[float(x),float(y),float(z)]; return item


def spin(item, x=0.0, y=0.0, z=0.0):
    item["angular_velocity"]=[float(x),float(y),float(z)]; return item


def light3d(scene, direction=None, ambient=0.24):
    light=scene.setdefault("light3d", {})
    if direction is not None: light["direction"]=[float(v) for v in direction]
    light["ambient"]=max(0.0,min(1.0,float(ambient)))
    return light


def _unit(v):
    length=math.sqrt(sum(x*x for x in v)) or 1.0
    return tuple(x/length for x in v)


def render3d(scene, canvas):
    graphics.clear(canvas,scene["background"])
    cam=scene.get("camera",{}); pos=cam.get("position",[0,0,-6]); target=cam.get("target",[0,0,0]); up=cam.get("up",[0,1,0])
    forward=_unit(tuple(target[i]-pos[i] for i in range(3)))
    right=_unit((forward[1]*up[2]-forward[2]*up[1],forward[2]*up[0]-forward[0]*up[2],forward[0]*up[1]-forward[1]*up[0]))
    vertical=(right[1]*forward[2]-right[2]*forward[1],right[2]*forward[0]-right[0]*forward[2],right[0]*forward[1]-right[1]*forward[0])
    fov=math.radians(float(cam.get("fov",60))); focal=(canvas["height"]*0.5)/math.tan(fov*0.5); camera_z=0.0; near=float(cam.get("near",0.1))
    light=scene.get("light3d",{}); world_light=light.get("direction",[-0.4,0.6,-1.0])
    view_light=(sum(world_light[i]*right[i] for i in range(3)),sum(world_light[i]*vertical[i] for i in range(3)),-sum(world_light[i]*forward[i] for i in range(3)))
    for item in scene.get("models",[]):
        if not item.get("visible",True): continue
        world=graphics3d.transform(item["mesh"],item["rotation"],item["position"],item["scale"])
        view=[]
        for vertex in world["vertices"]:
            rel=tuple(vertex[i]-pos[i] for i in range(3))
            x=sum(rel[i]*right[i] for i in range(3)); y=sum(rel[i]*vertical[i] for i in range(3)); depth=sum(rel[i]*forward[i] for i in range(3))
            view.append((x,y,camera_z-depth))
        graphics3d.render_solid(canvas,{"vertices":view,"faces":world["faces"]},item["color"],camera_z,focal,view_light,light.get("ambient",0.24),True,near)
    for item in scene.get("labels",[]): graphics.text(canvas,item["x"],item["y"],item["text"],item["color"],item["size"])
    return canvas


def velocity(e, vx, vy):
    e["vx"], e["vy"] = float(vx), float(vy)
    return e


def control(scene, player, speed=220, scheme="arrows"):
    """Attach built-in keyboard movement. Arrows/WASD are supported by the window host."""
    if player not in scene["entities"]:
        raise ValueError("Controlled entity must belong to this scene")
    control_data = {"entity": player, "speed": max(1.0, float(speed)), "scheme": str(scheme)}
    scene["controllers"] = [c for c in scene["controllers"] if c["entity"] is not player]
    scene["controllers"].append(control_data)
    scene["player"] = player
    return player


def collectible(scene, name, x, y, size=22, color="#6ee7ff"):
    item = entity(scene, name, x, y, size, size, color, "circle")
    item["kind"] = "collectible"
    return item


def label(scene, text, x=16, y=16, color="#ffffff", size=2):
    item = {"text": str(text), "x": float(x), "y": float(y), "color": color, "size": int(size)}
    scene["labels"].append(item)
    return item


def goal(scene, count, message="Goal complete!"):
    scene["goal"] = max(0, int(count))
    scene["message"] = str(message)
    return scene


def set_bounds(scene, enabled=True):
    scene["keep_player_in_bounds"] = bool(enabled)
    return scene


def update(scene, dt, gravity=0):
    dt = max(0.0, min(float(dt), .25))
    scene["time"] += dt
    for e in scene["entities"]:
        if e["kind"] == "collectible": continue
        e["vy"] += float(gravity) * dt
        e["x"] += e["vx"] * dt; e["y"] += e["vy"] * dt
    for item in scene.get("models",[]):
        for i in range(3):
            item["position"][i] += item["velocity"][i] * dt
            item["rotation"][i] += item["angular_velocity"][i] * dt
    return scene


def ambient(scene, color="#ffffff", intensity=0.72):
    """Set scene-wide ambient light; intensity is from 0 (dark) to 1 (full)."""
    scene["ambient_color"] = color
    scene["ambient_intensity"] = max(0.0, min(1.0, float(intensity)))
    return scene


def light(scene, x, y, radius=160, color="#fff0c2", intensity=1.0):
    """Add a soft radial point light in scene pixel coordinates."""
    item = {"x": float(x), "y": float(y), "radius": max(1.0, float(radius)),
            "color": color, "intensity": max(0.0, float(intensity)), "enabled": True}
    scene.setdefault("lights", []).append(item)
    return item


def remove_light(scene, item):
    if item in scene.get("lights", []):
        scene["lights"].remove(item)
        return True
    return False


def render(scene, canvas):
    if scene.get("dimension",2)==3: return render3d(scene,canvas)
    graphics.clear(canvas, scene["background"])
    for e in scene["entities"]:
        if not e["visible"]:
            continue
        x, y, w, h = e["x"], e["y"], e["width"], e["height"]
        if e["shape"] == "circle":
            graphics.circle(canvas, x + w / 2, y + h / 2, min(w, h) / 2, e["color"])
        elif e["shape"] == "text":
            graphics.text(canvas, x, y, e.get("text", e["name"]), e["color"], e.get("size", 1))
        else:
            graphics.rect(canvas, x, y, w, h, e["color"])
    for item in scene["labels"]:
        graphics.text(canvas, item["x"], item["y"], item["text"], item["color"], item["size"])
    graphics.apply_lighting(canvas, scene.get("ambient_color", "#ffffff"),
                            scene.get("ambient_intensity", 0.72),
                            [item for item in scene.get("lights", []) if item.get("enabled", True)])
    return canvas


def find(scene, name):
    return next((e for e in scene["entities"] if e["name"] == name), None)


def remove(scene, name):
    before = len(scene["entities"])
    scene["entities"][:] = [e for e in scene["entities"] if e["name"] != name]
    return len(scene["entities"]) != before


def collide(a, b):
    return not (
        a["x"] + a["width"] < b["x"] or b["x"] + b["width"] < a["x"]
        or a["y"] + a["height"] < b["y"] or b["y"] + b["height"] < a["y"]
    )


def run(scene, width=640, height=360, title=None, fps=60):
    """Open a live window and continuously update, light, and render the scene.

    Uses Tkinter and the RGBA software renderer; requires a desktop session.
    """
    from .window import run_game
    return run_game(scene, width, height, title or scene["name"], fps)
