"""Tk desktop host for Flux Engine's real-time 2D game loop."""
import time


def run_game(scene, width=640, height=360, title="Orbit Game", fps=60):
    """Run Flux through the same live RGBA renderer used by Orbit graphics."""
    from runtime.stdlib import graphics
    width, height = int(width), int(height)
    if not (160 <= width <= 2560 and 120 <= height <= 1600):
        raise ValueError("Flux window size must be between 160x120 and 2560x1600")
    fps = max(15, min(144, int(fps)))
    delay = 1.0 / fps
    display = graphics.open_window(width, height, title or scene["name"], fps, scene["background"])
    frame = graphics.canvas(width, height, scene["background"])
    scene["width"], scene["height"] = width, height
    pressed = set()
    previous = {"time": time.perf_counter()}

    root = display["root"]
    def key_name(event):
        return str(event.keysym).lower()
    def on_press(event):
        pressed.add(key_name(event))
        try:
            from runtime.stdlib import input as orbit_input
            orbit_input._STATE["keys"].add(key_name(event))
        except Exception:
            pass
        if key_name(event) == "escape":
            graphics.close_window(display)
    def on_release(event):
        pressed.discard(key_name(event))
        try:
            from runtime.stdlib import input as orbit_input
            orbit_input._STATE["keys"].discard(key_name(event))
        except Exception:
            pass
    def on_mouse_move(event):
        try:
            from runtime.stdlib import input as orbit_input
            orbit_input._STATE.update(mouse_x=event.x, mouse_y=event.y)
        except Exception:
            pass
    def on_mouse_down(event):
        try:
            from runtime.stdlib import input as orbit_input
            orbit_input._STATE["mouse_buttons"].add(int(event.num))
        except Exception:
            pass
    def on_mouse_up(event):
        try:
            from runtime.stdlib import input as orbit_input
            orbit_input._STATE["mouse_buttons"].discard(int(event.num))
        except Exception:
            pass
    root.bind_all("<KeyPress>", on_press)
    root.bind_all("<KeyRelease>", on_release)
    display["view"].bind("<Motion>", on_mouse_move)
    display["view"].bind("<ButtonPress>", on_mouse_down)
    display["view"].bind("<ButtonRelease>", on_mouse_up)

    from .core import update, collide, render
    while graphics.is_open(display):
        now = time.perf_counter()
        dt = max(0.0, min(now - previous["time"], 0.05))
        previous["time"] = now
        for control in scene.get("controllers", []):
            player = control["entity"]
            speed = control["speed"]
            scheme = control.get("scheme", "arrows")
            left_keys = {"left", "a"} if scheme in ("arrows", "wasd", "arrows_wasd") else {"left"}
            right_keys = {"right", "d"} if scheme in ("arrows", "wasd", "arrows_wasd") else {"right"}
            up_keys = {"up", "w"} if scheme in ("arrows", "wasd", "arrows_wasd") else {"up"}
            down_keys = {"down", "s"} if scheme in ("arrows", "wasd", "arrows_wasd") else {"down"}
            vx = (-speed if pressed & left_keys else 0.0) + (speed if pressed & right_keys else 0.0)
            vy = (-speed if pressed & up_keys else 0.0) + (speed if pressed & down_keys else 0.0)
            if vx and vy:
                vx *= 0.70710678
                vy *= 0.70710678
            player["vx"], player["vy"] = vx, vy
        for control3d in scene.get("controllers3d", []):
            item=control3d["model"]; speed=control3d["speed"]
            vx=(-speed if pressed & {"a","left"} else 0.0)+(speed if pressed & {"d","right"} else 0.0)
            vz=(-speed if pressed & {"s","down"} else 0.0)+(speed if pressed & {"w","up"} else 0.0)
            vy=(speed if "space" in pressed else 0.0)+(-speed if "shift_l" in pressed or "shift_r" in pressed else 0.0)
            if vx and vz: vx*=0.70710678; vz*=0.70710678
            item["velocity"]=[vx,vy,vz]
        update(scene, dt, scene.get("gravity", 0.0))
        player = scene.get("player")
        if player and scene.get("keep_player_in_bounds", True):
            player["x"] = max(0, min(width - player["width"], player["x"]))
            player["y"] = max(0, min(height - player["height"], player["y"]))
        if player:
            collected = [e for e in scene["entities"] if e.get("kind") == "collectible" and collide(player, e)]
            for item in collected:
                scene["entities"].remove(item)
                scene["score"] = int(scene.get("score", 0)) + 1
        render(scene, frame)
        if scene.get("goal", 0) > 0:
            from runtime.stdlib import graphics as gfx
            gfx.text(frame, 12, 10, f"CRYSTALS: {scene.get('score', 0)}/{scene['goal']}", "#ffffff", 2)
            if scene.get("score", 0) >= scene["goal"]:
                gfx.text(frame, max(8, width // 2 - 90), 42, scene.get("message", "Goal complete!"), "#fff4a3", 2)
        graphics.present(display, frame)
        elapsed = time.perf_counter() - now
        if elapsed < delay:
            time.sleep(delay - elapsed)
    try:
        from runtime.stdlib import input as orbit_input
        orbit_input._STATE["keys"].clear()
        orbit_input._STATE["mouse_buttons"].clear()
    except Exception:
        pass
    return {"closed": True, "score": int(scene.get("score", 0)), "time": float(scene.get("time", 0.0))}
